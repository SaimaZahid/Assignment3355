package com.example.assignment3355;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerMessages;
    private List<Message> messages;
    private MessageAdapter messageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("Gmail");
        getSupportActionBar().setElevation(0.0f);

        recyclerMessages = findViewById(R.id.recyclerMessages);

        loadMessages();
    }

    private void loadMessages() {
        messages = new ArrayList<>();

        messages.add(new Message("You have been granted admin access to promothean. Admins have full rights to the organization and have complete access to all repositories and teams."));
        messages.add(new Message("Admins have full rights to the organization and have complete access to all repositories and teams."));
        messages.add(new Message("You have been granted admin access to promothean. Admins have full rights to the organization and have complete access to all repositories and teams."));

        messageAdapter = new MessageAdapter(MainActivity.this, messages);
        recyclerMessages.setAdapter(messageAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuArchive:
                Toast.makeText(this, "Archive", Toast.LENGTH_SHORT).show();
                break;

            case R.id.menuDelete:
                Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(MainActivity.this);
        materialAlertDialogBuilder.setTitle("Close Application");
        materialAlertDialogBuilder.setMessage("Do you really want to close Gmail?");
        materialAlertDialogBuilder.setCancelable(false);
        materialAlertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        materialAlertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        materialAlertDialogBuilder.create().show();
    }
}